DENIRO WINDOWS UPDATE - 24 October 2026

Updates the existing original C:\Deniro program OR DENIRO Desktop 1.0.0.
It updates the program you already use. It does not open the browser, create a fresh shop, or move your saved data into a different program.

HOW TO UPDATE
1. In your current DENIRO, export Full Backup and keep a second copy on USB or another device.
2. Close DENIRO completely, including the tray icon.
3. Extract the WHOLE ZIP into a separate folder, outside the DENIRO installation and AppData folders.
4. Double-click START_UPDATE.bat. Use the same Windows account that normally uses DENIRO.
5. If both editions are installed, choose the program you normally use. Read the confirmation and backup locations.
6. Wait for the completion message. Open your usual DENIRO shortcut and check your existing stock, sales, balances, workers and PIWI before entering new transactions.

Do not uninstall DENIRO. Do not replace or delete its AppData folder.
No new activation key is needed for a recognized installation on the same computer.

WHAT IS INCLUDED
- Shared numeric barcode sequence starting at 001, skipping occupied codes across phones, accessories and PC stock.
- The latest purchase form, profit calculations and daily dashboard refinements.
- Cash/Baridimob images, including payment images in sales detail tables.
- The previous homepage, daily history, Settings, PIN controls, notifications, worker-account and return fixes in this chat.

DATA AND ACTIVATION
The updater copies and verifies all files in the relevant saved-data profile(s), including the business snapshots, browser storage, settings and license files, BEFORE replacing any existing program file.
It checks that DENIRO is closed and that profiles did not change during backup.
Saved-data profiles and activation files are never replaced, reset, or imported by the updater. You continue using the same profile and shortcut.
The original C:\Deniro edition receives only a new app\index.html; its launcher and preload remain unchanged.
DENIRO Desktop receives a new resources\app.asar and the matching, verified Windows executable metadata. The Electron runtime and device-bound license verification are unchanged. Its program version becomes 1.1.0; Windows Installed Apps may retain the original installer version label.
No demo records, empty databases, activation generators, or owner private keys are included.

BACKUPS
Documents\DENIRO_SAFE_UPDATE_BACKUPS\DENIRO_2026-10-25_...
Each backup includes Profiles, original Program files, and an update-record.json with file checksums.
Keep this folder as well as your external Full Backup. Local backups do not protect against disk failure.

SAFE STOP
Unknown versions, missing profiles, unreadable databases, running DENIRO processes, linked profile folders, or failed checksum/backup checks cause the update to stop.
Do not bypass the checks. Keep the error message for compatibility review.
If permissions prevent updating a protected installation, use an account with permission to that installation and access to the SAME saved-data profile. Do not switch Windows accounts or uninstall the program to get around the error.

ROLLBACK - PROGRAM ONLY
If replacing program files fails, the updater attempts to restore the original program files immediately.
If the update was interrupted or you need the previous interface, close DENIRO, then run RESTORE_PREVIOUS_PROGRAM.bat from this extracted update folder. It verifies the original program backup before restoring it.
Rollback keeps the CURRENT saved-data profile, including any later transactions. It never restores an older database over newer sales.
If an interrupted update cannot be restored automatically, retain the pending-update message and backups. Do not delete the AppData profile.

CHECKS AND LIMITS
The Windows payload is built for the existing x64 DENIRO Desktop runtime; the original C:\Deniro edition keeps its installed runtime. Business rules, saved-data persistence, activation checks, archive hashes, program-file compatibility, backup verification and failure rollback are checked in isolated tests. No physical Windows computer, printer, or scanner was available here. These checks cannot guarantee every device or zero risk. Keep your verified external backup and test one label/scan on your actual Windows equipment.
The original application is not publisher-signed; Windows may show an unknown-publisher warning for this locally supplied update. This package does not require disabling antivirus or system-wide security settings.

ONLINE UPDATES
DENIRO Desktop 1.1.0 checks the signed DENIRO update feed. It prompts before download and installation.
Original C:\Deniro edition receives a verified ZIP download notice; close DENIRO and run START_UPDATE.bat from the extracted ZIP to install.
No shop records or activation key are uploaded. Mac release publishing is managed from the owner Mac.

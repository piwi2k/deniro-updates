﻿# Compatible with Windows PowerShell 5.1. No function writes to a saved-data profile.
Set-StrictMode -Version 2
$ErrorActionPreference='Stop'
function Get-DeniroHash([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()}
function Join-DeniroPath([string]$Root,[string]$Relative){
 if([IO.Path]::IsPathRooted($Relative) -or ($Relative -split '[\\/]') -contains '..'){throw 'Unsafe relative path'}
 $base=[IO.Path]::GetFullPath($Root).TrimEnd([IO.Path]::DirectorySeparatorChar)+[IO.Path]::DirectorySeparatorChar
 $path=[IO.Path]::GetFullPath((Join-Path $Root $Relative.Replace('\',[IO.Path]::DirectorySeparatorChar)))
 if(!$path.StartsWith($base,[StringComparison]::OrdinalIgnoreCase)){throw 'Path leaves the expected folder'}
 return $path
}
function Test-DeniroInside([string]$Path,[string]$Root){
 $p=[IO.Path]::GetFullPath($Path).TrimEnd([IO.Path]::DirectorySeparatorChar)
 $r=[IO.Path]::GetFullPath($Root).TrimEnd([IO.Path]::DirectorySeparatorChar)
 return $p.Equals($r,[StringComparison]::OrdinalIgnoreCase) -or $p.StartsWith($r+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)
}
function Get-DeniroFiles([string]$Root){
 $result=New-Object System.Collections.Generic.List[object]
 $walk={param($Folder)
  foreach($item in @(Get-ChildItem -LiteralPath $Folder -Force -ErrorAction Stop)){
   if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw ('Cannot safely back up a linked file/folder: '+$item.FullName)}
   if($item.PSIsContainer){& $walk $item.FullName}else{
    $relative=$item.FullName.Substring($Root.TrimEnd([IO.Path]::DirectorySeparatorChar).Length).TrimStart([IO.Path]::DirectorySeparatorChar)
    $result.Add([pscustomobject]@{Path=$relative;Length=$item.Length;Hash=(Get-DeniroHash $item.FullName)})
   }
  }
 }
 & $walk $Root
 return $result.ToArray()
}
function Assert-DeniroTree([string]$Root,[object[]]$Files){
 $now=@(Get-DeniroFiles $Root)
 if($now.Count -ne $Files.Count){throw ('Saved-data files changed while backing up: '+$Root)}
 foreach($file in $Files){$path=Join-DeniroPath $Root $file.Path;if(!(Test-Path -LiteralPath $path -PathType Leaf) -or (Get-DeniroHash $path) -ne $file.Hash){throw ('Backup verification failed: '+$file.Path)}}
}
function Copy-DeniroTree([string]$Source,[string]$Destination){
 $files=@(Get-DeniroFiles $Source)
 if($files.Count -eq 0){throw ('Saved-data folder is empty: '+$Source)}
 New-Item -ItemType Directory -Force -Path $Destination|Out-Null
 foreach($file in $files){$to=Join-DeniroPath $Destination $file.Path;New-Item -ItemType Directory -Force -Path (Split-Path -Parent $to)|Out-Null;Copy-Item -LiteralPath (Join-DeniroPath $Source $file.Path) -Destination $to -ErrorAction Stop}
 Assert-DeniroTree $Destination $files
 Assert-DeniroTree $Source $files
 return $files
}
function Test-DeniroSnapshot([string]$Path){
 try{
  $s=Get-Content -LiteralPath $Path -Raw -Encoding UTF8|ConvertFrom-Json -ErrorAction Stop
  if($null -eq $s -or $null -eq $s.PSObject.Properties['state'] -or $null -eq $s.state -or $s.state -is [array] -or $s.state -is [string]){return $false}
  if($null -eq $s.PSObject.Properties['revision']){return $false}
  $revision=0L;if(![long]::TryParse([string]$s.revision,[ref]$revision) -or $revision -lt 0){return $false}
  $count=0;foreach($p in $s.state.PSObject.Properties){if($p.Name -notmatch '^(demo_sp_|sp_|deniro_|setting_|stocky|piwi_)' -or $p.Value -isnot [string]){return $false};$count++}
  return $count -gt 0
 }catch{return $false}
}
function New-DeniroPatchedFile([string]$Source,[string]$Destination,$Patch){
 if((Get-DeniroHash $Source) -ne $Patch.before_sha256){throw 'Desktop executable baseline mismatch'}
 if((Get-Item -LiteralPath $Source).Length -ne [long]$Patch.length){throw 'Desktop executable length mismatch'}
 Copy-Item -LiteralPath $Source -Destination $Destination -ErrorAction Stop
 $stream=[IO.File]::Open($Destination,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
 try{
  foreach($part in $Patch.parts){
   $before=[Convert]::FromBase64String($part.before);$after=[Convert]::FromBase64String($part.after)
   if($before.Length -ne $after.Length -or [long]$part.offset -lt 0 -or ([long]$part.offset+$after.Length) -gt $stream.Length){throw 'Invalid desktop executable patch'}
   $null=$stream.Seek([long]$part.offset,[IO.SeekOrigin]::Begin);$buffer=New-Object byte[] $before.Length
   if($stream.Read($buffer,0,$buffer.Length) -ne $buffer.Length -or [Convert]::ToBase64String($buffer) -ne $part.before){throw 'Desktop patch original bytes mismatch'}
   $null=$stream.Seek([long]$part.offset,[IO.SeekOrigin]::Begin);$stream.Write($after,0,$after.Length)
  }
  $stream.Flush($true)
 }finally{$stream.Dispose()}
 if((Get-DeniroHash $Destination) -ne $Patch.after_sha256){throw 'Patched executable does not match the verified Windows build'}
}
function Restore-DeniroOperations($Plan,[string]$BackupRoot){
 foreach($op in @($Plan.Operations)){
  $source=Join-DeniroPath (Join-Path $BackupRoot 'Program') $op.Path
  if(!(Test-Path -LiteralPath $source -PathType Leaf) -or (Get-DeniroHash $source) -ne $op.Before){throw ('Original program backup mismatch: '+$op.Path)}
 }
 foreach($op in @($Plan.Operations)){
  $target=Join-DeniroPath $Plan.Root $op.Path
  if((Test-Path -LiteralPath $target -PathType Leaf) -and (Get-DeniroHash $target) -eq $op.Before){continue}
  $temp=$target+'.deniro-restore-'+[guid]::NewGuid().ToString('N')
  try{
   Copy-Item -LiteralPath (Join-DeniroPath (Join-Path $BackupRoot 'Program') $op.Path) -Destination $temp -ErrorAction Stop
   if(Test-Path -LiteralPath $target){[IO.File]::Replace($temp,$target,[NullString]::Value)}else{[IO.File]::Move($temp,$target)}
   if((Get-DeniroHash $target) -ne $op.Before){throw 'Program rollback verification failed'}
  }finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
 }
}
function Invoke-DeniroUpdate($Plan,[string]$PackageRoot,[string]$BackupParent,[object[]]$Profiles,[scriptblock]$CheckStopped,[scriptblock]$TestHook=$null){
 if($Profiles.Count -eq 0){throw 'No saved-data profile found. No program files changed.'}
 if(Test-DeniroInside $PackageRoot $Plan.Root){throw 'Extract the update outside the DENIRO installation folder'}
 if($CheckStopped){& $CheckStopped}
 $pending=Join-Path $Plan.Root 'DENIRO_UPDATE_PENDING.json';if(Test-Path -LiteralPath $pending){throw 'An earlier update was interrupted. Run RESTORE_PREVIOUS_PROGRAM.bat first.'}
 foreach($op in $Plan.Operations){if((Get-DeniroHash (Join-DeniroPath $Plan.Root $op.Path)) -ne $op.Before){throw 'Installed program changed before backup'}}
 $backup=Join-Path $BackupParent ('DENIRO_2026-10-25_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'_'+[guid]::NewGuid().ToString('N').Substring(0,8))
 New-Item -ItemType Directory -Force -Path $backup|Out-Null
 $profileReports=New-Object System.Collections.Generic.List[object];$validDatabases=0;$changed=$false;$stage=$null
 try{
  foreach($profile in $Profiles){
   $source=[IO.Path]::GetFullPath([string]$profile)
   if((Test-DeniroInside $backup $source) -or (Test-DeniroInside $PackageRoot $source)){throw 'The update or backup folder must be outside saved-data profiles'}
   $name=Split-Path -Leaf $source;$dest=Join-Path (Join-Path $backup 'Profiles') $name
   if(Test-Path -LiteralPath $dest){throw 'Duplicate profile folder name; cannot back up safely'}
   $files=@(Copy-DeniroTree $source $dest);$dbs=@($files|Where-Object{[IO.Path]::GetFileName($_.Path) -in @('smilephone-local.json','smilephone-local-mirror.json')})
   if($dbs.Count -gt 0){$valid=0;foreach($db in $dbs){if(Test-DeniroSnapshot (Join-DeniroPath $dest $db.Path)){$valid++}};if($valid -eq 0){throw ('No readable saved business database in '+$source)};$validDatabases+=$valid}
   $profileReports.Add([pscustomobject]@{Source=$source;Destination=$dest;Files=$files})
  }
  if($validDatabases -eq 0){throw 'No readable DENIRO business database was backed up. No program files changed.'}
  foreach($op in $Plan.Operations){
   $from=Join-DeniroPath $Plan.Root $op.Path;$to=Join-DeniroPath (Join-Path $backup 'Program') $op.Path
   New-Item -ItemType Directory -Force -Path (Split-Path -Parent $to)|Out-Null;Copy-Item -LiteralPath $from -Destination $to -ErrorAction Stop
   if((Get-DeniroHash $to) -ne $op.Before){throw 'Program backup checksum mismatch'}
  }
  # Reference copies preserve the original native launcher/preload, without editing them.
  if($Plan.Kind -eq 'legacy'){foreach($ref in @('main.js','preload.js')){Copy-Item -LiteralPath (Join-Path $Plan.Root $ref) -Destination (Join-Path $backup ($ref+'.reference')) -ErrorAction Stop}}
  $stage=Join-Path $Plan.Root ('.deniro-update-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $stage|Out-Null
  foreach($op in $Plan.Operations){
   $to=Join-DeniroPath $stage $op.Path;New-Item -ItemType Directory -Force -Path (Split-Path -Parent $to)|Out-Null
   $payload=Join-DeniroPath $PackageRoot $op.Payload
   if(!(Test-Path -LiteralPath $payload -PathType Leaf) -or (Get-DeniroHash $payload) -ne $op.PayloadHash){throw 'Update payload checksum mismatch'}
   if($op.Mode -eq 'patch'){$patch=Get-Content -LiteralPath $payload -Raw -Encoding UTF8|ConvertFrom-Json;New-DeniroPatchedFile (Join-DeniroPath $Plan.Root $op.Path) $to $patch}else{Copy-Item -LiteralPath $payload -Destination $to -ErrorAction Stop}
   if((Get-DeniroHash $to) -ne $op.After){throw 'Staged program checksum mismatch'}
  }
  foreach($report in $profileReports){Assert-DeniroTree $report.Source @($report.Files)}
  foreach($op in $Plan.Operations){if((Get-DeniroHash (Join-DeniroPath $Plan.Root $op.Path)) -ne $op.Before){throw 'Installed program changed during backup'}}
  if($CheckStopped){& $CheckStopped}
  $record=[pscustomobject]@{Release='2026-10-25';Root=$Plan.Root;Kind=$Plan.Kind;Backup=$backup;Operations=@($Plan.Operations);Profiles=@($profileReports.ToArray());Status='pending'}
  $record|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $backup 'update-record.json') -Encoding UTF8
  $record|Select-Object Release,Root,Kind,Backup,Operations,Status|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $pending -Encoding UTF8
  $i=0
  foreach($op in $Plan.Operations){
   if($TestHook){& $TestHook $i $op}
   $changed=$true;[IO.File]::Replace((Join-DeniroPath $stage $op.Path),(Join-DeniroPath $Plan.Root $op.Path),[NullString]::Value)
   if((Get-DeniroHash (Join-DeniroPath $Plan.Root $op.Path)) -ne $op.After){throw 'Installed update checksum mismatch'};$i++
  }
  foreach($report in $profileReports){Assert-DeniroTree $report.Source @($report.Files)}
  $record.Status='complete';$record|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $backup 'update-record.json') -Encoding UTF8
  $record|Select-Object Release,Root,Kind,Backup,Operations,Status|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $Plan.Root 'DENIRO_LAST_UPDATE.json') -Encoding UTF8
  Remove-Item -LiteralPath $pending -Force
  return [pscustomobject]@{Success=$true;Backup=$backup;Kind=$Plan.Kind}
 }catch{
  $message=$_.Exception.Message
  if($changed -or (Test-Path -LiteralPath $pending)){
   try{Restore-DeniroOperations $Plan $backup;if(Test-Path -LiteralPath $pending){Remove-Item -LiteralPath $pending -Force};$message+=' Original program files restored.'}catch{$message+=' ROLLBACK NEEDS ATTENTION. Run RESTORE_PREVIOUS_PROGRAM.bat. '+$_.Exception.Message}
  }
  throw ($message+' Backup folder: '+$backup)
 }finally{if($stage -and (Test-Path -LiteralPath $stage)){Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue}}
}

﻿#requires -Version 5.1
param([switch]$Rollback)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
function Alert([string]$Message,[string]$Title='DENIRO Windows Update',[string]$Icon='Information'){
 [System.Windows.Forms.MessageBox]::Show($Message,$Title,[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::$Icon)|Out-Null
}
function Property($Object,[string]$Name,[object]$Default=$null){if($null -eq $Object){return $Default};$p=$Object.PSObject.Properties[$Name];if($null -eq $p){return $Default};return $p.Value}
$package=Split-Path -Parent $MyInvocation.MyCommand.Path
$backupParent=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'DENIRO_SAFE_UPDATE_BACKUPS'
try{
 if($env:OS -ne 'Windows_NT'){throw 'This package runs on Windows only.'}
 $manifest=Get-Content -LiteralPath (Join-Path $package 'manifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
 foreach($helper in @('Update.Core.ps1')){if((Get-FileHash -LiteralPath (Join-Path $package $helper) -Algorithm SHA256).Hash -ne $manifest.core_sha256){throw 'Updater file checksum mismatch. Extract the complete ZIP again.'}}
 . (Join-Path $package 'Update.Core.ps1')
 function Check-Stopped{
  $running=@(Get-CimInstance Win32_Process -ErrorAction Stop|Where-Object{($_.Name -match '^(electron|DENIRO.*)\.exe$') -or ($_.ExecutablePath -like 'C:\Deniro\*') -or ($_.ExecutablePath -like ($target.Root.TrimEnd('\')+'\*'))})
  if($running.Count -gt 0){throw 'Close DENIRO completely, including its tray icon, then run this update again.'}
 }
 function Find-Targets{
  $targets=New-Object System.Collections.Generic.List[object];$roots=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
  if((Test-Path 'C:\Deniro\app\index.html') -and (Test-Path 'C:\Deniro\main.js') -and (Test-Path 'C:\Deniro\preload.js')){$targets.Add([pscustomobject]@{Kind='legacy';Root='C:\Deniro';Label='DENIRO - original program (C:\Deniro)'})}
  $local=[Environment]::GetFolderPath('LocalApplicationData')
  foreach($name in @('DENIRO Desktop','deniro-desktop')){if($local){$null=$roots.Add((Join-Path (Join-Path $local 'Programs') $name))};if($env:ProgramFiles){$null=$roots.Add((Join-Path $env:ProgramFiles $name))}}
  foreach($registry in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')){
   if(!(Test-Path $registry)){continue}
   foreach($entry in @(Get-ChildItem $registry|Get-ItemProperty)){
    if((Property $entry 'DisplayName' '') -notlike 'DENIRO Desktop*'){continue}
    $location=Property $entry 'InstallLocation' ''
    if(!$location){$uninstall=Property $entry 'UninstallString' '';if($uninstall -match '^"([^"]+)"'){$location=Split-Path -Parent $matches[1]}}
    if($location){$null=$roots.Add([IO.Path]::GetFullPath($location))}
   }
  }
  foreach($root in $roots){if((Test-Path -LiteralPath (Join-Path $root 'DENIRO Desktop.exe')) -and (Test-Path -LiteralPath (Join-Path $root 'resources\app.asar'))){$targets.Add([pscustomobject]@{Kind='desktop';Root=$root;Label=('DENIRO Desktop - '+$root)})}}
  return $targets.ToArray()
 }
 function Select-Target([object[]]$Targets){
  if($Targets.Count -eq 0){throw 'No supported DENIRO installation was found. No files changed. This package updates an existing installation; it does not create a new database.'}
  if($Targets.Count -eq 1){return $Targets[0]}
  $form=New-Object System.Windows.Forms.Form;$form.Text='Choose your installed DENIRO';$form.Width=760;$form.Height=250;$form.StartPosition='CenterScreen'
  $label=New-Object System.Windows.Forms.Label;$label.Text='Two editions were found. Select the one you normally use. Only that program will be updated.';$label.SetBounds(20,20,700,42)
  $combo=New-Object System.Windows.Forms.ComboBox;$combo.DropDownStyle='DropDownList';$combo.SetBounds(20,70,700,35);foreach($t in $Targets){$null=$combo.Items.Add($t.Label)};$combo.SelectedIndex=-1
  $ok=New-Object System.Windows.Forms.Button;$ok.Text='Continue';$ok.SetBounds(490,125,110,35);$ok.Enabled=$false;$ok.DialogResult=[System.Windows.Forms.DialogResult]::OK
  $cancel=New-Object System.Windows.Forms.Button;$cancel.Text='Cancel';$cancel.SetBounds(610,125,110,35);$cancel.DialogResult=[System.Windows.Forms.DialogResult]::Cancel
  $combo.Add_SelectedIndexChanged({$ok.Enabled=$combo.SelectedIndex -ge 0});$form.Controls.AddRange(@($label,$combo,$ok,$cancel));$form.AcceptButton=$ok;$form.CancelButton=$cancel
  if($form.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK){$form.Dispose();return $null};$index=$combo.SelectedIndex;$form.Dispose();return $Targets[$index]
 }
 function Get-Plan($Target){
  $operations=@()
  if($Target.Kind -eq 'legacy'){
   $old=Get-DeniroHash (Join-Path $Target.Root 'app\index.html');$cfg=$manifest.legacy
   if($old -eq $cfg.after_sha256){return [pscustomobject]@{Already=$true;Root=$Target.Root;Kind=$Target.Kind}}
   if(@($cfg.supported_before_sha256) -notcontains $old){throw 'Unrecognized original DENIRO version. Safe stop: no program or data files changed.'}
   $operations+= [pscustomobject]@{Path='app/index.html';Before=$old;After=$cfg.after_sha256;Mode='copy';Payload='payload/legacy/index.html';PayloadHash=$cfg.after_sha256}
  }else{
   $exe=Get-DeniroHash (Join-Path $Target.Root 'DENIRO Desktop.exe');$asar=Get-DeniroHash (Join-Path $Target.Root 'resources\app.asar');$cfg=$manifest.desktop
   if($exe -eq $cfg.after_exe_sha256 -and $asar -eq $cfg.after_asar_sha256){return [pscustomobject]@{Already=$true;Root=$Target.Root;Kind=$Target.Kind}}
   $baseline=@($cfg.baselines|Where-Object{$_.exe_sha256 -eq $exe -and $_.asar_sha256 -eq $asar})
   if($baseline.Count -ne 1){throw 'Unrecognized DENIRO Desktop build or interrupted update. Safe stop. Use RESTORE_PREVIOUS_PROGRAM.bat if an update was interrupted.'}
   $operations+=[pscustomobject]@{Path='resources/app.asar';Before=$asar;After=$cfg.after_asar_sha256;Mode='copy';Payload='payload/desktop/app.asar';PayloadHash=$cfg.after_asar_sha256}
   $operations+=[pscustomobject]@{Path='DENIRO Desktop.exe';Before=$exe;After=$cfg.after_exe_sha256;Mode='patch';Payload=$baseline[0].patch;PayloadHash=$baseline[0].patch_sha256}
  }
  return [pscustomobject]@{Already=$false;Root=$Target.Root;Kind=$Target.Kind;Operations=$operations}
 }
 function Restore-Selected($Target){
  $file=Join-Path $Target.Root 'DENIRO_UPDATE_PENDING.json';if(!(Test-Path -LiteralPath $file)){$file=Join-Path $Target.Root 'DENIRO_LAST_UPDATE.json'}
  if(!(Test-Path -LiteralPath $file)){throw 'No verified update rollback record was found. Saved data was not changed.'}
  $record=Get-Content -LiteralPath $file -Raw -Encoding UTF8|ConvertFrom-Json
  if($record.Release -ne '2026-10-25' -or $record.Kind -ne $Target.Kind -or [IO.Path]::GetFullPath($record.Root) -ne [IO.Path]::GetFullPath($Target.Root) -or !(Test-DeniroInside $record.Backup $backupParent)){throw 'Rollback record does not match this program'}
  $expected=if($Target.Kind -eq 'legacy'){@('app/index.html')}else{@('resources/app.asar','DENIRO Desktop.exe')}
  if(@($record.Operations).Count -ne $expected.Count){throw 'Unexpected rollback file list'}
  foreach($op in $record.Operations){
   if($expected -notcontains $op.Path){throw 'Unexpected rollback program path'}
   $allowed=if($op.Path -eq 'app/index.html'){@($manifest.legacy.supported_before_sha256)}elseif($op.Path -eq 'resources/app.asar'){@($manifest.desktop.baselines|ForEach-Object{$_.asar_sha256})}else{@($manifest.desktop.baselines|ForEach-Object{$_.exe_sha256})}
   if($allowed -notcontains $op.Before){throw 'Unrecognized original program checksum in rollback record'}
  }
  $answer=[System.Windows.Forms.MessageBox]::Show('Restore the previous program files? Your current sales, stock, balances and activation are kept. Saved-data backups will NOT be restored.','DENIRO - restore program only',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
  if($answer -ne [System.Windows.Forms.DialogResult]::Yes){return}
  Check-Stopped;Restore-DeniroOperations $record $record.Backup
  foreach($name in @('DENIRO_UPDATE_PENDING.json','DENIRO_LAST_UPDATE.json')){$path=Join-Path $Target.Root $name;if(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path -Force}}
  Alert 'Previous program files restored. Current saved data and activation were kept. Open your usual shortcut.'
 }
 $targets=@(Find-Targets);$target=Select-Target $targets;if($null -eq $target){exit 0}
 Check-Stopped
 if($Rollback){Restore-Selected $target;exit 0}
 if(Test-Path -LiteralPath (Join-Path $target.Root 'DENIRO_UPDATE_PENDING.json')){throw 'A previous update was interrupted. Run RESTORE_PREVIOUS_PROGRAM.bat. It restores only program files, keeping current data.'}
 $plan=Get-Plan $target;if($plan.Already){Alert 'This update is already installed. Your saved data was not changed.';exit 0}
 $roaming=[Environment]::GetFolderPath('ApplicationData')
 if($target.Kind -eq 'desktop'){$profiles=@((Join-Path $roaming 'DENIRO Desktop')|Where-Object{Test-Path -LiteralPath $_ -PathType Container})}else{$profiles=@(Get-ChildItem -LiteralPath $roaming -Directory -Force|Where-Object{$_.Name -match '(?i)deniro|piwi' -and $_.Name -ne 'DENIRO Desktop'}|ForEach-Object{$_.FullName})}
 if($profiles.Count -eq 0){throw 'Cannot find the saved-data folder for this edition. No files changed. Run as the same Windows user who uses DENIRO.'}
 $message="Update $($target.Label)?`n`nA complete saved-data and original-program backup will be verified first. Only program files will be replaced. Stock, sales, balances, settings, and your activation key stay in the same folders.`n`nKeep an external Full Backup too. Do not uninstall DENIRO.`n`nProfiles being protected:`n"+($profiles -join "`n")
 $answer=[System.Windows.Forms.MessageBox]::Show($message,'DENIRO - update existing program',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
 if($answer -ne [System.Windows.Forms.DialogResult]::Yes){exit 0}
 Write-Host 'Backing up and verifying saved data. Keep this window open...'
 $result=Invoke-DeniroUpdate $plan $package $backupParent $profiles ${function:Check-Stopped}
 Alert ("Update completed.`n`nVerified backup: $($result.Backup)`n`nOpen your usual DENIRO shortcut. Your existing data and activation were kept. Check your stock, sales and balances before entering new transactions.") 'DENIRO - update completed'
 exit 0
}catch{
 Alert ($_.Exception.Message+"`n`nSaved-data profiles are never replaced by this updater. Keep your backups. If the update stopped, keep this message.") 'DENIRO - update stopped' 'Warning'
 exit 1
}

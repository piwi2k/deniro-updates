@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_DENIRO.ps1"
if errorlevel 1 (
 echo DENIRO stopped safely. Read the message above.
)
pause
